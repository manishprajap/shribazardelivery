System.register(["./index.esm-legacy-DiLWI22Z.js"],function(e,r){"use strict";var i;return{setters:[r=>{r.i,i=r.r,e({FirebaseError:r.F,SDK_VERSION:r.S,_DEFAULT_ENTRY_NAME:r.D,_addComponent:r._,_addOrOverwriteComponent:r.a,_apps:r.b,_clearComponents:r.c,_components:r.d,_getProvider:r.e,_isFirebaseApp:r.f,_isFirebaseServerApp:r.g,_isFirebaseServerAppSettings:r.h,_registerComponent:r.j,_removeServiceInstance:r.k,_serverApps:r.l,deleteApp:r.m,getApp:r.n,getApps:r.o,initializeApp:r.i,initializeServerApp:r.p,onLog:r.q,registerVersion:r.r,setLogLevel:r.s})}],execute:function(){
/**
			 * @license
			 * Copyright 2020 Google LLC
			 *
			 * Licensed under the Apache License, Version 2.0 (the "License");
			 * you may not use this file except in compliance with the License.
			 * You may obtain a copy of the License at
			 *
			 *   http://www.apache.org/licenses/LICENSE-2.0
			 *
			 * Unless required by applicable law or agreed to in writing, software
			 * distributed under the License is distributed on an "AS IS" BASIS,
			 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
			 * See the License for the specific language governing permissions and
			 * limitations under the License.
			 */
i("firebase","12.15.0","app")}}});
