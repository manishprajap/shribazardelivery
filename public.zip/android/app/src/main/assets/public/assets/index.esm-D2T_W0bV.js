import{r as _,j as C,C as D,e as j,E as de,t as L,F as Ue,u as h,n as Ve,v as We,w as Ge,x as Je,y as R}from"./index.esm-pXv-TqTj.js";const fe="@firebase/installations",q="0.6.22";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const le=1e4,pe="w:".concat(q),ge="FIS_v2",ze="https://firebaseinstallations.googleapis.com/v1",Ye=60*60*1e3,Qe="installations",Xe="Installations";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ze={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."},b=new de(Qe,Xe,Ze);function he(e){return e instanceof Ue&&e.code.includes("request-failed")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function we({projectId:e}){return"".concat(ze,"/projects/").concat(e,"/installations")}function be(e){return{token:e.token,requestStatus:2,expiresIn:tt(e.expiresIn),creationTime:Date.now()}}async function ye(e,t){const i=(await t.json()).error;return b.create("request-failed",{requestName:e,serverCode:i.code,serverMessage:i.message,serverStatus:i.status})}function Te({apiKey:e}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e})}function et(e,{refreshToken:t}){const n=Te(e);return n.append("Authorization",nt(t)),n}async function Ie(e){const t=await e();return t.status>=500&&t.status<600?e():t}function tt(e){return Number(e.replace("s","000"))}function nt(e){return"".concat(ge," ").concat(e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function it({appConfig:e,heartbeatServiceProvider:t},{fid:n}){const i=we(e),r=Te(e),o=t.getImmediate({optional:!0});if(o){const f=await o.getHeartbeatsHeader();f&&r.append("x-firebase-client",f)}const a={fid:n,authVersion:ge,appId:e.appId,sdkVersion:pe},s={method:"POST",headers:r,body:JSON.stringify(a)},d=await Ie(()=>fetch(i,s));if(d.ok){const f=await d.json();return{fid:f.fid||n,registrationStatus:2,refreshToken:f.refreshToken,authToken:be(f.authToken)}}else throw await ye("Create Installation",d)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function me(e){return new Promise(t=>{setTimeout(t,e)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rt(e){return btoa(String.fromCharCode(...e)).replace(/\+/g,"-").replace(/\//g,"_")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ot=/^[cdef][\w-]{21}$/,x="";function at(){try{const e=new Uint8Array(17);(self.crypto||self.msCrypto).getRandomValues(e),e[0]=112+e[0]%16;const n=st(e);return ot.test(n)?n:x}catch(e){return x}}function st(e){return rt(e).substr(0,22)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function m(e){return"".concat(e.appName,"!").concat(e.appId)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const T=new Map;function Se(e,t){const n=m(e);ke(n,t),dt(n,t)}function ct(e,t){ve();const n=m(e);let i=T.get(n);i||(i=new Set,T.set(n,i)),i.add(t)}function ut(e,t){const n=m(e),i=T.get(n);i&&(i.delete(t),i.size===0&&T.delete(n),Ae())}function ke(e,t){const n=T.get(e);if(n)for(const i of n)i(t)}function dt(e,t){const n=ve();n&&n.postMessage({key:e,fid:t}),Ae()}let w=null;function ve(){return!w&&"BroadcastChannel"in self&&(w=new BroadcastChannel("[Firebase] FID Change"),w.onmessage=e=>{ke(e.data.key,e.data.fid)}),w}function Ae(){T.size===0&&w&&(w.close(),w=null)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ft="firebase-installations-database",lt=1,y="firebase-installations-store";let M=null;function B(){return M||(M=L(ft,lt,{upgrade:(e,t)=>{switch(t){case 0:e.createObjectStore(y)}}})),M}async function N(e,t){const n=m(e),r=(await B()).transaction(y,"readwrite"),o=r.objectStore(y),a=await o.get(n);return await o.put(t,n),await r.done,(!a||a.fid!==t.fid)&&Se(e,t.fid),t}async function Ee(e){const t=m(e),i=(await B()).transaction(y,"readwrite");await i.objectStore(y).delete(t),await i.done}async function O(e,t){const n=m(e),r=(await B()).transaction(y,"readwrite"),o=r.objectStore(y),a=await o.get(n),s=t(a);return s===void 0?await o.delete(n):await o.put(s,n),await r.done,s&&(!a||a.fid!==s.fid)&&Se(e,s.fid),s}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function U(e){let t;const n=await O(e.appConfig,i=>{const r=pt(i),o=gt(e,r);return t=o.registrationPromise,o.installationEntry});return n.fid===x?{installationEntry:await t}:{installationEntry:n,registrationPromise:t}}function pt(e){const t=e||{fid:at(),registrationStatus:0};return Re(t)}function gt(e,t){if(t.registrationStatus===0){if(!navigator.onLine){const r=Promise.reject(b.create("app-offline"));return{installationEntry:t,registrationPromise:r}}const n={fid:t.fid,registrationStatus:1,registrationTime:Date.now()},i=ht(e,n);return{installationEntry:n,registrationPromise:i}}else return t.registrationStatus===1?{installationEntry:t,registrationPromise:wt(e)}:{installationEntry:t}}async function ht(e,t){try{const n=await it(e,t);return N(e.appConfig,n)}catch(n){throw he(n)&&n.customData.serverCode===409?await Ee(e.appConfig):await N(e.appConfig,{fid:t.fid,registrationStatus:0}),n}}async function wt(e){let t=await Y(e.appConfig);for(;t.registrationStatus===1;)await me(100),t=await Y(e.appConfig);if(t.registrationStatus===0){const{installationEntry:n,registrationPromise:i}=await U(e);return i||n}return t}function Y(e){return O(e,t=>{if(!t)throw b.create("installation-not-found");return Re(t)})}function Re(e){return bt(e)?{fid:e.fid,registrationStatus:0}:e}function bt(e){return e.registrationStatus===1&&e.registrationTime+le<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function yt({appConfig:e,heartbeatServiceProvider:t},n){const i=Tt(e,n),r=et(e,n),o=t.getImmediate({optional:!0});if(o){const f=await o.getHeartbeatsHeader();f&&r.append("x-firebase-client",f)}const a={installation:{sdkVersion:pe,appId:e.appId}},s={method:"POST",headers:r,body:JSON.stringify(a)},d=await Ie(()=>fetch(i,s));if(d.ok){const f=await d.json();return be(f)}else throw await ye("Generate Auth Token",d)}function Tt(e,{fid:t}){return"".concat(we(e),"/").concat(t,"/authTokens:generate")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function V(e,t=!1){let n;const i=await O(e.appConfig,o=>{if(!_e(o))throw b.create("not-registered");const a=o.authToken;if(!t&&St(a))return o;if(a.requestStatus===1)return n=It(e,t),o;{if(!navigator.onLine)throw b.create("app-offline");const s=vt(o);return n=mt(e,s),s}});return n?await n:i.authToken}async function It(e,t){let n=await Q(e.appConfig);for(;n.authToken.requestStatus===1;)await me(100),n=await Q(e.appConfig);const i=n.authToken;return i.requestStatus===0?V(e,t):i}function Q(e){return O(e,t=>{if(!_e(t))throw b.create("not-registered");const n=t.authToken;return At(n)?{...t,authToken:{requestStatus:0}}:t})}async function mt(e,t){try{const n=await yt(e,t),i={...t,authToken:n};return await N(e.appConfig,i),n}catch(n){if(he(n)&&(n.customData.serverCode===401||n.customData.serverCode===404))await Ee(e.appConfig);else{const i={...t,authToken:{requestStatus:0}};await N(e.appConfig,i)}throw n}}function _e(e){return e!==void 0&&e.registrationStatus===2}function St(e){return e.requestStatus===2&&!kt(e)}function kt(e){const t=Date.now();return t<e.creationTime||e.creationTime+e.expiresIn<t+Ye}function vt(e){const t={requestStatus:1,requestTime:Date.now()};return{...e,authToken:t}}function At(e){return e.requestStatus===1&&e.requestTime+le<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Et(e){const t=e,{installationEntry:n,registrationPromise:i}=await U(t);return i?i.catch(console.error):V(t).catch(console.error),n.fid}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Rt(e,t=!1){const n=e;return await _t(n),(await V(n,t)).token}async function _t(e){const{registrationPromise:t}=await U(e);t&&await t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ct(e,t){const{appConfig:n}=e;return ct(n,t),()=>{ut(n,t)}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Dt(e){if(!e||!e.options)throw P("App Configuration");if(!e.name)throw P("App Name");const t=["projectId","apiKey","appId"];for(const n of t)if(!e.options[n])throw P(n);return{appName:e.name,projectId:e.options.projectId,apiKey:e.options.apiKey,appId:e.options.appId}}function P(e){return b.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ce="installations",Nt="installations-internal",Ot=e=>{const t=e.getProvider("app").getImmediate(),n=Dt(t),i=j(t,"heartbeat");return{app:t,appConfig:n,heartbeatServiceProvider:i,_delete:()=>Promise.resolve()}},Ft=e=>{const t=e.getProvider("app").getImmediate(),n=j(t,Ce).getImmediate();return{getId:()=>Et(n),getToken:r=>Rt(n,r)}};function Mt(){C(new D(Ce,Ot,"PUBLIC")),C(new D(Nt,Ft,"PRIVATE"))}Mt();_(fe,q);_(fe,q,"esm2020");/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pt="/firebase-messaging-sw.js",Kt="/firebase-cloud-messaging-push-scope",De="BDOU99-h67HcA6JeFXHbSNMu7e2yNNu3RzoMj8TM4W88jITfq7ZmPvIM1Iv-4_l2LxQcYwhqby2xGpWwzjfAnG4",$t="https://fcmregistrations.googleapis.com/v1",Ne="google.c.a.c_id",xt="google.c.a.c_l",Ht="google.c.a.ts",jt="google.c.a.e",X=1e4;var Z;(function(e){e[e.DATA_MESSAGE=1]="DATA_MESSAGE",e[e.DISPLAY_NOTIFICATION=3]="DISPLAY_NOTIFICATION"})(Z||(Z={}));/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */var I;(function(e){e.PUSH_RECEIVED="push-received",e.NOTIFICATION_CLICKED="notification-clicked",e.FID_REGISTERED="fid-registered"})(I||(I={}));/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function l(e){const t=new Uint8Array(e);return btoa(String.fromCharCode(...t)).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_")}function Oe(e){const t="=".repeat((4-e.length%4)%4),n=(e+t).replace(/\-/g,"+").replace(/_/g,"/"),i=atob(n),r=new Uint8Array(i.length);for(let o=0;o<i.length;++o)r[o]=i.charCodeAt(o);return r}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const K="fcm_token_details_db",Lt=5,ee="fcm_token_object_Store";async function qt(e){if("databases"in indexedDB&&!(await indexedDB.databases()).map(o=>o.name).includes(K))return null;let t=null;return(await L(K,Lt,{upgrade:async(i,r,o,a)=>{var f;if(r<2||!i.objectStoreNames.contains(ee))return;const s=a.objectStore(ee),d=await s.index("fcmSenderId").get(e);if(await s.clear(),!!d){if(r===2){const c=d;if(!c.auth||!c.p256dh||!c.endpoint)return;t={token:c.fcmToken,createTime:(f=c.createTime)!=null?f:Date.now(),subscriptionOptions:{auth:c.auth,p256dh:c.p256dh,endpoint:c.endpoint,swScope:c.swScope,vapidKey:typeof c.vapidKey=="string"?c.vapidKey:l(c.vapidKey)}}}else if(r===3){const c=d;t={token:c.fcmToken,createTime:c.createTime,subscriptionOptions:{auth:l(c.auth),p256dh:l(c.p256dh),endpoint:c.endpoint,swScope:c.swScope,vapidKey:l(c.vapidKey)}}}else if(r===4){const c=d;t={token:c.fcmToken,createTime:c.createTime,subscriptionOptions:{auth:l(c.auth),p256dh:l(c.p256dh),endpoint:c.endpoint,swScope:c.swScope,vapidKey:l(c.vapidKey)}}}}}})).close(),await R(K),await R("fcm_vapid_details_db"),await R("undefined"),Bt(t)?t:null}function Bt(e){if(!e||!e.subscriptionOptions)return!1;const{subscriptionOptions:t}=e;return typeof e.createTime=="number"&&e.createTime>0&&typeof e.token=="string"&&e.token.length>0&&typeof t.auth=="string"&&t.auth.length>0&&typeof t.p256dh=="string"&&t.p256dh.length>0&&typeof t.endpoint=="string"&&t.endpoint.length>0&&typeof t.swScope=="string"&&t.swScope.length>0&&typeof t.vapidKey=="string"&&t.vapidKey.length>0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ut={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"only-available-in-window":"This method is available in a Window context.","only-available-in-sw":"This method is available in a service worker context.","permission-default":"The notification permission was not granted and dismissed instead.","permission-blocked":"The notification permission was not granted and blocked instead.","unsupported-browser":"This browser doesn't support the API's required to use the Firebase SDK.","indexed-db-unsupported":"This browser doesn't support indexedDb.open() (ex. Safari iFrame, Firefox Private Browsing, etc)","failed-service-worker-registration":"We are unable to register the default service worker. {$browserErrorMessage}","token-subscribe-failed":"A problem occurred while subscribing the user to FCM: {$errorInfo}","token-subscribe-no-token":"FCM returned no token when subscribing the user to push.","fid-registration-failed":"A problem occurred while creating an FCM registration via FID: {$errorInfo}","fid-unregister-failed":"A problem occurred while unregistering the FCM registration via FID: {$errorInfo}","fid-registration-idb-schema-unavailable":"Unable to read or persist FID registration metadata because the messaging IndexedDB schema is unavailable (for example, the database could not be upgraded to the latest version).","token-unsubscribe-failed":"A problem occurred while unsubscribing the user from FCM: {$errorInfo}","token-update-failed":"A problem occurred while updating the user from FCM: {$errorInfo}","token-update-no-token":"FCM returned no token when updating the user to push.","use-sw-after-get-token":"The useServiceWorker() method may only be called once and must be called before calling getToken() to ensure your service worker is used.","invalid-sw-registration":"The input to useServiceWorker() must be a ServiceWorkerRegistration.","invalid-bg-handler":"The input to setBackgroundMessageHandler() must be a function.","invalid-vapid-key":"The public VAPID key must be a string.","use-vapid-key-after-get-token":"The usePublicVapidKey() method may only be called once and must be called before calling getToken() to ensure your VAPID key is used.","invalid-on-registered-handler":"No onRegistered callback handler was provided or registered. Implement onRegistered() before register()."},u=new de("messaging","Messaging",Ut);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const te="firebase-messaging-database",ne=2,g="firebase-messaging-store",p="firebase-messaging-fid-registration-store",Vt={openDB:L,deleteDB:R};let ie=Vt,v=null;function Wt(e,t,n){switch(t){case 0:if(e.createObjectStore(g),n===1)break;case 1:n===2&&e.createObjectStore(p)}}function re(e){return{upgrade:(t,n)=>{Wt(t,n,e)},blocked:()=>{},blocking:(t,n,i)=>{var r;v=null,(r=i.target)==null||r.close()},terminated:()=>{v=null}}}function S(){return v||(v=ie.openDB(te,ne,re(2)).catch(()=>ie.openDB(te,ne-1,re(1)))),v}function Fe(e,t){return e.objectStoreNames.contains(t)}function W(e){if(!Fe(e,p))throw u.create("fid-registration-idb-schema-unavailable")}async function Me(e){const t=k(e),i=await(await S()).transaction(g).objectStore(g).get(t);if(i)return i;{const r=await qt(e.appConfig.senderId);if(r)return await G(e,r),r}}async function G(e,t){const n=k(e),i=await S(),r=[g],o=Fe(i,p);o&&r.push(p);const a=i.transaction(r,"readwrite");return await a.objectStore(g).put(t,n),o&&await a.objectStore(p).delete(n),await a.done,t}async function Pe(e){const t=k(e),i=(await S()).transaction(g,"readwrite");await i.objectStore(g).delete(t),await i.done}async function F(e){const t=k(e),n=await S();return W(n),await n.transaction(p).objectStore(p).get(t)}async function Gt(e,t){const n=k(e),i=await S();W(i);const r=i.transaction([g,p],"readwrite");return await r.objectStore(p).put(t,n),await r.objectStore(g).delete(n),await r.done,t}async function Ke(e){const t=k(e),n=await S();W(n);const i=n.transaction(p,"readwrite");await i.objectStore(p).delete(t),await i.done}function k({appConfig:e}){return e.appId}const oe="@firebase/messaging",H="0.13.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Jt=3,zt=1e3;async function Yt(e,t){const n=await E(e),i=J(t,e.appConfig.appName,!1),r={method:"POST",headers:n,body:JSON.stringify(i)};let o;try{o=await(await fetch(A(e.appConfig),r)).json()}catch(a){throw u.create("token-subscribe-failed",{errorInfo:a==null?void 0:a.toString()})}if(o.error){const a=o.error.message;throw u.create("token-subscribe-failed",{errorInfo:a})}if(!o.token)throw u.create("token-subscribe-no-token");return o.token}async function Qt(e,t){var d,f;const n=await E(e),i=J(t,e.appConfig.appName,!0),r={method:"POST",headers:n,body:JSON.stringify(i)};let o;try{o=await tn(()=>fetch(A(e.appConfig),r),Jt,zt)}catch(c){throw u.create("fid-registration-failed",{errorInfo:c==null?void 0:c.toString()})}if(o.ok)return{responseFid:await Xt(o)};let a;try{a=await o.json()}catch(c){throw u.create("fid-registration-failed",{errorInfo:o.statusText})}const s=(f=(d=a.error)==null?void 0:d.message)!=null?f:o.statusText;throw u.create("fid-registration-failed",{errorInfo:s})}async function $e(e,t){var o,a;const i={method:"DELETE",headers:await E(e)};let r;try{r=await fetch("".concat(A(e.appConfig),"/").concat(t),i)}catch(s){throw u.create("fid-unregister-failed",{errorInfo:s==null?void 0:s.toString()})}if(!r.ok)try{throw(a=(o=(await r.json()).error)==null?void 0:o.message)!=null?a:r.statusText}catch(s){throw u.create("fid-unregister-failed",{errorInfo:typeof s=="string"&&s||r.statusText||(s==null?void 0:s.toString())})}}async function Xt(e){const t=await e.text();if(!t.trim())throw u.create("fid-registration-failed",{errorInfo:"CreateRegistration succeeded but response body is empty"});let n;try{n=JSON.parse(t)}catch(r){throw u.create("fid-registration-failed",{errorInfo:"CreateRegistration succeeded but response body is not valid JSON"})}const i=n.name;if(typeof i!="string"||i.length===0)throw u.create("fid-registration-failed",{errorInfo:"CreateRegistration succeeded but response did not include a non-empty name"});return Zt(i)}const ae="/registrations/";function Zt(e){const t=e.indexOf(ae);if(t!==-1){const n=e.slice(t+ae.length);if(n.length>0)return n}throw u.create("fid-registration-failed",{errorInfo:"CreateRegistration succeeded but response name is not a valid registration resource name"})}async function en(e,t){const n=await E(e),i=J(t.subscriptionOptions,e.appConfig.appName,!1),r={method:"PATCH",headers:n,body:JSON.stringify(i)};let o;try{o=await(await fetch("".concat(A(e.appConfig),"/").concat(t.token),r)).json()}catch(a){throw u.create("token-update-failed",{errorInfo:a==null?void 0:a.toString()})}if(o.error){const a=o.error.message;throw u.create("token-update-failed",{errorInfo:a})}if(!o.token)throw u.create("token-update-no-token");return o.token}async function xe(e,t){const i={method:"DELETE",headers:await E(e)};try{const o=await(await fetch("".concat(A(e.appConfig),"/").concat(t),i)).json();if(o.error){const a=o.error.message;throw u.create("token-unsubscribe-failed",{errorInfo:a})}}catch(r){throw u.create("token-unsubscribe-failed",{errorInfo:r==null?void 0:r.toString()})}}async function tn(e,t,n){let i;for(let r=0;r<t;r++)try{return await e()}catch(o){if(i=o,r<t-1){const a=n*Math.pow(2,r);await new Promise(s=>setTimeout(s,a))}}throw i}function A({projectId:e}){return"".concat($t,"/projects/").concat(e,"/registrations")}async function E({appConfig:e,installations:t}){const n=await t.getToken();return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e.apiKey,"x-goog-firebase-installations-auth":"FIS ".concat(n)})}function nn(e,t){var n,i;try{if(/^[a-zA-Z][a-zA-Z\d+\-.]*:/.test(e))return new URL(e).host}catch(r){}try{if(typeof self<"u"&&((n=self.location)!=null&&n.href))return new URL(e,self.location.origin).host}catch(r){}return typeof self<"u"&&((i=self.location)!=null&&i.host)?self.location.host:t}function J({p256dh:e,auth:t,endpoint:n,vapidKey:i,swScope:r},o,a){const s={web:{origin:nn(r,o),endpoint:n,auth:t,p256dh:e}};return a&&(s.fcm_sdk_version=H),i!==De&&(s.web.applicationPubKey=i),s}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rn=7*24*60*60*1e3;async function on(e){const t=await dn(e.swRegistration,e.vapidKey),n={vapidKey:e.vapidKey,swScope:e.swRegistration.scope,endpoint:t.endpoint,auth:l(t.getKey("auth")),p256dh:l(t.getKey("p256dh"))},i=await Me(e.firebaseDependencies);if(i){if(fn(i.subscriptionOptions,n))return Date.now()>=i.createTime+rn?un(e,{token:i.token,createTime:Date.now(),subscriptionOptions:n}):i.token;try{await xe(e.firebaseDependencies,i.token)}catch(r){console.warn(r)}return se(e.firebaseDependencies,n)}else return se(e.firebaseDependencies,n)}async function an(e,t){await xe(e.firebaseDependencies,t.token),await Pe(e.firebaseDependencies),await He(e.firebaseDependencies)}async function sn(e){const t=await F(e.firebaseDependencies).catch(()=>{}),n=t==null?void 0:t.fid;n&&await $e(e.firebaseDependencies,n),await He(e.firebaseDependencies),n&&pn(e,n)}async function cn(e){const t=await Me(e.firebaseDependencies);t?await an(e,t):await sn(e);const n=await e.swRegistration.pushManager.getSubscription();return n?n.unsubscribe():!0}async function un(e,t){try{const n=await en(e.firebaseDependencies,t),i={...t,token:n,createTime:Date.now()};return await G(e.firebaseDependencies,i),n}catch(n){throw n}}async function se(e,t){const i={token:await Yt(e,t),createTime:Date.now(),subscriptionOptions:t};return await G(e,i),i.token}async function dn(e,t){const n=await e.pushManager.getSubscription();return n||e.pushManager.subscribe({userVisibleOnly:!0,applicationServerKey:Oe(t)})}function fn(e,t){const n=t.vapidKey===e.vapidKey,i=t.endpoint===e.endpoint,r=t.auth===e.auth,o=t.p256dh===e.p256dh;return n&&i&&r&&o}async function He(e){try{await Ke(e)}catch(t){}}function ln(e,t){const n=e.onRegisteredHandler;n&&(typeof n=="function"?n(t):n.next(t))}function pn(e,t){const n=e.onUnregisteredHandler;n&&(typeof n=="function"?n(t):n.next(t))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function je(e){try{e.swRegistration=await navigator.serviceWorker.register(Pt,{scope:Kt}),e.swRegistration.update().catch(()=>{}),await gn(e.swRegistration)}catch(t){throw u.create("failed-service-worker-registration",{browserErrorMessage:t==null?void 0:t.message})}}async function gn(e){return new Promise((t,n)=>{const i=setTimeout(()=>n(new Error("Service worker not registered after ".concat(X," ms"))),X),r=e.installing||e.waiting;e.active?(clearTimeout(i),t()):r?r.onstatechange=o=>{var a;((a=o.target)==null?void 0:a.state)==="activated"&&(r.onstatechange=null,clearTimeout(i),t())}:(clearTimeout(i),n(new Error("No incoming service worker found.")))})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Le(e,t){if(!t&&!e.swRegistration&&await je(e),!(!t&&e.swRegistration)){if(!(t instanceof ServiceWorkerRegistration))throw u.create("invalid-sw-registration");e.swRegistration=t}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function qe(e,t){t?e.vapidKey=t:e.vapidKey||(e.vapidKey=De)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ce=3;async function hn(e,t){const n=await wn(e.swRegistration,e.vapidKey),i={vapidKey:e.vapidKey,swScope:e.swRegistration.scope,endpoint:n.endpoint,auth:l(n.getKey("auth")),p256dh:l(n.getKey("p256dh"))},r=e.firebaseDependencies.installations;for(let o=0;o<ce;o++){const{responseFid:a}=await Qt(e.firebaseDependencies,i);if(a===t)return;o<ce-1&&await r.getToken(!0)}throw u.create("fid-registration-failed",{errorInfo:"CreateRegistration response FID does not match Firebase Installation ID"})}async function wn(e,t){const n=await e.pushManager.getSubscription();return n||e.pushManager.subscribe({userVisibleOnly:!0,applicationServerKey:Oe(t)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bn=7*24*60*60*1e3;async function z(e,t){if(!navigator)throw u.create("only-available-in-window");if(Notification.permission==="default"&&await Notification.requestPermission(),Notification.permission!=="granted")throw u.create("permission-blocked");if(!e.onRegisteredHandler)throw u.create("invalid-on-registered-handler");await qe(e,t==null?void 0:t.vapidKey),await Le(e,t==null?void 0:t.serviceWorkerRegistration);const n=e._registerNotifyChain.catch(()=>{});return e._registerNotifyChain=n.then(async()=>{const i=await e.firebaseDependencies.installations.getId(),r=await F(e.firebaseDependencies),o=Date.now();if((!r||r.fid!==i||o>=r.lastRegisterTime+bn)&&(await hn(e,i),await Gt(e.firebaseDependencies,{fid:i,lastRegisterTime:o,vapidKey:e.vapidKey})),!e.onRegisteredHandler)throw u.create("invalid-on-registered-handler");ln(e,i)}),e._registerNotifyChain}/**
 * @license
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function yn(e,t){return Ct(t,()=>{(async()=>!e.onRegisteredHandler||!await F(e.firebaseDependencies)||await z(e).catch(()=>{}))()})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ue(e){const t={from:e.from,collapseKey:e.collapse_key,messageId:e.fcmMessageId};return Tn(t,e),In(t,e),mn(t,e),t}function Tn(e,t){if(!t.notification)return;e.notification={};const n=t.notification.title;n&&(e.notification.title=n);const i=t.notification.body;i&&(e.notification.body=i);const r=t.notification.image;r&&(e.notification.image=r);const o=t.notification.icon;o&&(e.notification.icon=o)}function In(e,t){t.data&&(e.data=t.data)}function mn(e,t){var r,o,a,s,d;if(!t.fcmOptions&&!((r=t.notification)!=null&&r.click_action))return;e.fcmOptions={};const n=(s=(o=t.fcmOptions)==null?void 0:o.link)!=null?s:(a=t.notification)==null?void 0:a.click_action;n&&(e.fcmOptions.link=n);const i=(d=t.fcmOptions)==null?void 0:d.analytics_label;i&&(e.fcmOptions.analyticsLabel=i)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sn(e){return typeof e=="object"&&!!e&&Ne in e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function kn(e){if(!e||!e.options)throw $("App Configuration Object");if(!e.name)throw $("App Name");const t=["projectId","apiKey","appId","messagingSenderId"],{options:n}=e;for(const i of t)if(!n[i])throw $(i);return{appName:e.name,projectId:n.projectId,apiKey:n.apiKey,appId:n.appId,senderId:n.messagingSenderId}}function $(e){return u.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vn{constructor(t,n,i){this.deliveryMetricsExportedToBigQueryEnabled=!1,this.onBackgroundMessageHandler=null,this.onMessageHandler=null,this.onRegisteredHandler=null,this.onUnregisteredHandler=null,this._registerNotifyChain=Promise.resolve(),this._fidChangeUnsubscribe=null,this.logEvents=[],this.logQueue={state:"stopped"};const r=kn(t);this.firebaseDependencies={app:t,appConfig:r,installations:n,analyticsProvider:i}}_delete(){return this._fidChangeUnsubscribe&&(this._fidChangeUnsubscribe(),this._fidChangeUnsubscribe=null),this.logQueue.state==="scheduled"&&clearTimeout(this.logQueue.timerId),this.logQueue={state:"stopped"},Promise.resolve()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Be(e,t){if(!navigator)throw u.create("only-available-in-window");if(Notification.permission==="default"&&await Notification.requestPermission(),Notification.permission!=="granted")throw u.create("permission-blocked");return await qe(e,t==null?void 0:t.vapidKey),await Le(e,t==null?void 0:t.serviceWorkerRegistration),on(e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function An(e,t,n){const i=En(t);(await e.firebaseDependencies.analyticsProvider.get()).logEvent(i,{message_id:n[Ne],message_name:n[xt],message_time:n[Ht],message_device_time:Math.floor(Date.now()/1e3)})}function En(e){switch(e){case I.NOTIFICATION_CLICKED:return"notification_open";case I.PUSH_RECEIVED:return"notification_foreground";default:throw new Error}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Rn(e,t){const n=t.data;if(!n.isFirebaseMessaging)return;if(e.onMessageHandler&&n.messageType===I.PUSH_RECEIVED&&(typeof e.onMessageHandler=="function"?e.onMessageHandler(ue(n)):e.onMessageHandler.next(ue(n))),e.onRegisteredHandler&&n.messageType===I.FID_REGISTERED){const r=n.fid;typeof e.onRegisteredHandler=="function"?e.onRegisteredHandler(r):e.onRegisteredHandler.next(r)}const i=n.data;Sn(i)&&i[jt]==="1"&&await An(e,n.messageType,i)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _n=e=>{const t=new vn(e.getProvider("app").getImmediate(),e.getProvider("installations-internal").getImmediate(),e.getProvider("analytics-internal"));return navigator.serviceWorker.addEventListener("message",n=>Rn(t,n)),t._fidChangeUnsubscribe=yn(t,e.getProvider("installations").getImmediate()),t},Cn=e=>{const t=e.getProvider("messaging").getImmediate();return{getToken:i=>Be(t,i),register:i=>z(t,i)}};function Dn(){C(new D("messaging",_n,"PUBLIC")),C(new D("messaging-internal",Cn,"PRIVATE")),_(oe,H),_(oe,H,"esm2020")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Nn(){try{await We()}catch(e){return!1}return typeof window<"u"&&Ge()&&Je()&&"serviceWorker"in navigator&&"PushManager"in window&&"Notification"in window&&"fetch"in window&&ServiceWorkerRegistration.prototype.hasOwnProperty("showNotification")&&PushSubscription.prototype.hasOwnProperty("getKey")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function On(e){if(!navigator)throw u.create("only-available-in-window");return e.swRegistration||await je(e),cn(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fn(e,t){if(!navigator)throw u.create("only-available-in-window");return e.onMessageHandler=t,()=>{e.onMessageHandler=null}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Mn(e,t){return e.onRegisteredHandler=t,()=>{e.onRegisteredHandler===t&&(e.onRegisteredHandler=null)}}/**
 * @license
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pn(e,t){return e.onUnregisteredHandler=t,()=>{e.onUnregisteredHandler===t&&(e.onUnregisteredHandler=null)}}/**
 * @license
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Kn(e){var r;if(!navigator)throw u.create("only-available-in-window");const t=await F(e.firebaseDependencies).catch(()=>{}),n=(r=t==null?void 0:t.fid)!=null?r:await e.firebaseDependencies.installations.getId();await $e(e.firebaseDependencies,n);try{await Ke(e.firebaseDependencies)}catch(o){}try{await Pe(e.firebaseDependencies)}catch(o){}const i=e.onUnregisteredHandler;i&&(typeof i=="function"?i(n):i.next(n))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xn(e=Ve()){return Nn().then(t=>{if(!t)throw u.create("unsupported-browser")},t=>{throw u.create("indexed-db-unsupported")}),j(h(e),"messaging").getImmediate()}async function Hn(e,t){return e=h(e),Be(e,t)}function jn(e){return e=h(e),On(e)}function Ln(e,t){return e=h(e),Fn(e,t)}async function qn(e,t){return e=h(e),z(e,t)}async function Bn(e){return e=h(e),Kn(e)}function Un(e,t){return e=h(e),Mn(e,t)}function Vn(e,t){return e=h(e),Pn(e,t)}Dn();export{jn as deleteToken,xn as getMessaging,Hn as getToken,Nn as isSupported,Ln as onMessage,Un as onRegistered,Vn as onUnregistered,qn as register,Bn as unregister};
