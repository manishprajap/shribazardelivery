System.register(["./index.esm-legacy-DiLWI22Z.js"],function(e,t){"use strict";var n,i,a,r,o,s,c,u,d,f,l,p,g;return{setters:[e=>{n=e.r,i=e.j,a=e.C,r=e.e,o=e.E,s=e.t,c=e.F,u=e.u,d=e.n,f=e.v,l=e.w,p=e.x,g=e.y}],execute:function(){e({deleteToken:function(e){
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */return async function(e){if(!navigator)throw he.create("only-available-in-window");return e.swRegistration||await Qe(e),Je(e)}
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(e=u(e))},getMessaging:
/**
             * @license
             * Copyright 2017 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
function(e=d()){return dt().then(e=>{if(!e)throw he.create("unsupported-browser")},e=>{throw he.create("indexed-db-unsupported")}),r(u(e),"messaging").getImmediate()},getToken:async function(e,t){return ot(e=u(e),t)},isSupported:dt,onMessage:function(e,t){return function(e,t){if(!navigator)throw he.create("only-available-in-window");return e.onMessageHandler=t,()=>{e.onMessageHandler=null}}
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(e=u(e),t)},onRegistered:function(e,t){return function(e,t){return e.onRegisteredHandler=t,()=>{e.onRegisteredHandler===t&&(e.onRegisteredHandler=null)}}
/**
             * @license
             * Copyright 2026 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(e=u(e),t)},onUnregistered:function(e,t){return function(e,t){return e.onUnregisteredHandler=t,()=>{e.onUnregisteredHandler===t&&(e.onUnregisteredHandler=null)}}
/**
             * @license
             * Copyright 2026 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(e=u(e),t)},register:async function(e,t){return nt(e=u(e),t)},unregister:async function(e){return async function(e){var t;if(!navigator)throw he.create("only-available-in-window");const n=await je(e.firebaseDependencies).catch(()=>{}),i=null!==(t=null==n?void 0:n.fid)&&void 0!==t?t:await e.firebaseDependencies.installations.getId();await xe(e.firebaseDependencies,i);try{await Ee(e.firebaseDependencies)}catch{}try{await _e(e.firebaseDependencies)}catch{}const a=e.onUnregisteredHandler;a&&("function"==typeof a?a(i):a.next(i))}(e=u(e))}});const t="@firebase/installations",w="0.6.22",h=1e4,y=`w:${w}`,m="FIS_v2",b=36e5,v=new o("installations","Installations",{"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."});function k(e){return e instanceof c&&e.code.includes("request-failed")}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */function I({projectId:e}){return`https://firebaseinstallations.googleapis.com/v1/projects/${e}/installations`}function S(e){return{token:e.token,requestStatus:2,expiresIn:(t=e.expiresIn,Number(t.replace("s","000"))),creationTime:Date.now()};var t}async function T(e,t){const n=(await t.json()).error;return v.create("request-failed",{requestName:e,serverCode:n.code,serverMessage:n.message,serverStatus:n.status})}function C({apiKey:e}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e})}function D(e,{refreshToken:t}){const n=C(e);return n.append("Authorization",function(e){return`${m} ${e}`}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(t)),n}async function P(e){const t=await e();return t.status>=500&&t.status<600?e():t}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */function R(e){return new Promise(t=>{setTimeout(t,e)})}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
const _=/^[cdef][\w-]{21}$/;function j(){try{const e=new Uint8Array(17);(self.crypto||self.msCrypto).getRandomValues(e),e[0]=112+e[0]%16;const t=function(e){const t=(n=e,btoa(String.fromCharCode(...n)).replace(/\+/g,"-").replace(/\//g,"_"));var n;return t.substr(0,22)}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(e);return _.test(t)?t:""}catch{return""}}function E(e){return`${e.appName}!${e.appId}`}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */const N=new Map;function K(e,t){const n=E(e);M(n,t),function(e,t){const n=A();n&&n.postMessage({key:e,fid:t}),H()}(n,t)}function M(e,t){const n=N.get(e);if(n)for(const i of n)i(t)}let O=null;function A(){return!O&&"BroadcastChannel"in self&&(O=new BroadcastChannel("[Firebase] FID Change"),O.onmessage=e=>{M(e.data.key,e.data.fid)}),O}function H(){0===N.size&&O&&(O.close(),O=null)}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */const x="firebase-installations-store";let F=null;function $(){return F||(F=s("firebase-installations-database",1,{upgrade:(e,t)=>{0===t&&e.createObjectStore(x)}})),F}async function q(e,t){const n=E(e),i=(await $()).transaction(x,"readwrite"),a=i.objectStore(x),r=await a.get(n);return await a.put(t,n),await i.done,r&&r.fid===t.fid||K(e,t.fid),t}async function U(e){const t=E(e),n=(await $()).transaction(x,"readwrite");await n.objectStore(x).delete(t),await n.done}async function B(e,t){const n=E(e),i=(await $()).transaction(x,"readwrite"),a=i.objectStore(x),r=await a.get(n),o=t(r);return void 0===o?await a.delete(n):await a.put(o,n),await i.done,!o||r&&r.fid===o.fid||K(e,o.fid),o}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */async function L(e){let t;const n=await B(e.appConfig,n=>{const i=function(e){const t=e||{fid:j(),registrationStatus:0};return J(t)}(n),a=function(e,t){if(0===t.registrationStatus){if(!navigator.onLine)return{installationEntry:t,registrationPromise:Promise.reject(v.create("app-offline"))};const n={fid:t.fid,registrationStatus:1,registrationTime:Date.now()},i=async function(e,t){try{const n=await async function({appConfig:e,heartbeatServiceProvider:t},{fid:n}){const i=I(e),a=C(e),r=t.getImmediate({optional:!0});if(r){const e=await r.getHeartbeatsHeader();e&&a.append("x-firebase-client",e)}const o={fid:n,authVersion:m,appId:e.appId,sdkVersion:y},s={method:"POST",headers:a,body:JSON.stringify(o)},c=await P(()=>fetch(i,s));if(c.ok){const e=await c.json();return{fid:e.fid||n,registrationStatus:2,refreshToken:e.refreshToken,authToken:S(e.authToken)}}throw await T("Create Installation",c)}(e,t);return q(e.appConfig,n)}catch(n){throw k(n)&&409===n.customData.serverCode?await U(e.appConfig):await q(e.appConfig,{fid:t.fid,registrationStatus:0}),n}}(e,n);return{installationEntry:n,registrationPromise:i}}return 1===t.registrationStatus?{installationEntry:t,registrationPromise:V(e)}:{installationEntry:t}}(e,i);return t=a.registrationPromise,a.installationEntry});return""===n.fid?{installationEntry:await t}:{installationEntry:n,registrationPromise:t}}async function V(e){let t=await W(e.appConfig);for(;1===t.registrationStatus;)await R(100),t=await W(e.appConfig);if(0===t.registrationStatus){const{installationEntry:t,registrationPromise:n}=await L(e);return n||t}return t}function W(e){return B(e,e=>{if(!e)throw v.create("installation-not-found");return J(e)})}function J(e){return 1===(t=e).registrationStatus&&t.registrationTime+h<Date.now()?{fid:e.fid,registrationStatus:0}:e;var t;
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */}async function z({appConfig:e,heartbeatServiceProvider:t},n){const i=function(e,{fid:t}){return`${I(e)}/${t}/authTokens:generate`}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(e,n),a=D(e,n),r=t.getImmediate({optional:!0});if(r){const e=await r.getHeartbeatsHeader();e&&a.append("x-firebase-client",e)}const o={installation:{sdkVersion:y,appId:e.appId}},s={method:"POST",headers:a,body:JSON.stringify(o)},c=await P(()=>fetch(i,s));if(c.ok)return S(await c.json());throw await T("Generate Auth Token",c)}async function G(e,t=!1){let n;const i=await B(e.appConfig,i=>{if(!Y(i))throw v.create("not-registered");const a=i.authToken;if(!t&&function(e){return 2===e.requestStatus&&!function(e){const t=Date.now();return t<e.creationTime||e.creationTime+e.expiresIn<t+b}(e)}(a))return i;if(1===a.requestStatus)return n=async function(e,t){let n=await Q(e.appConfig);for(;1===n.authToken.requestStatus;)await R(100),n=await Q(e.appConfig);const i=n.authToken;return 0===i.requestStatus?G(e,t):i}(e,t),i;{if(!navigator.onLine)throw v.create("app-offline");const t=function(e){const t={requestStatus:1,requestTime:Date.now()};return{...e,authToken:t}}(i);return n=async function(e,t){try{const n=await z(e,t),i={...t,authToken:n};return await q(e.appConfig,i),n}catch(n){if(!k(n)||401!==n.customData.serverCode&&404!==n.customData.serverCode){const n={...t,authToken:{requestStatus:0}};await q(e.appConfig,n)}else await U(e.appConfig);throw n}}(e,t),t}});return n?await n:i.authToken}function Q(e){return B(e,e=>{if(!Y(e))throw v.create("not-registered");const t=e.authToken;return 1===(n=t).requestStatus&&n.requestTime+h<Date.now()?{...e,authToken:{requestStatus:0}}:e;var n;
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */})}function Y(e){return void 0!==e&&2===e.registrationStatus}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
async function Z(e,t=!1){const n=e;return await async function(e){const{registrationPromise:t}=await L(e);t&&await t}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(n),(await G(n,t)).token}function X(e,t){const{appConfig:n}=e;return function(e,t){A();const n=E(e);let i=N.get(n);i||(i=new Set,N.set(n,i)),i.add(t)}(n,t),()=>{!function(e,t){const n=E(e),i=N.get(n);i&&(i.delete(t),0===i.size&&N.delete(n),H())}(n,t)}}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */function ee(e){return v.create("missing-app-config-values",{valueName:e})}
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */const te="installations",ne=e=>{const t=e.getProvider("app").getImmediate(),n=r(t,te).getImmediate();return{getId:()=>async function(e){const t=e,{installationEntry:n,registrationPromise:i}=await L(t);return i?i.catch(console.error):G(t).catch(console.error),n.fid}(n),getToken:e=>Z(n,e)}};i(new a(te,e=>{const t=e.getProvider("app").getImmediate(),n=function(e){if(!e||!e.options)throw ee("App Configuration");if(!e.name)throw ee("App Name");const t=["projectId","apiKey","appId"];for(const n of t)if(!e.options[n])throw ee(n);return{appName:e.name,projectId:e.options.projectId,apiKey:e.options.apiKey,appId:e.options.appId}}(t);return{app:t,appConfig:n,heartbeatServiceProvider:r(t,"heartbeat"),_delete:()=>Promise.resolve()}},"PUBLIC")),i(new a("installations-internal",ne,"PRIVATE")),n(t,w),n(t,w,"esm2020");
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
const ie="/firebase-messaging-sw.js",ae="/firebase-cloud-messaging-push-scope",re="BDOU99-h67HcA6JeFXHbSNMu7e2yNNu3RzoMj8TM4W88jITfq7ZmPvIM1Iv-4_l2LxQcYwhqby2xGpWwzjfAnG4",oe="https://fcmregistrations.googleapis.com/v1",se="google.c.a.c_id",ce=1e4;var ue,de;
/**
             * @license
             * Copyright 2017 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
function fe(e){const t=new Uint8Array(e);return btoa(String.fromCharCode(...t)).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_")}function le(e){const t=(e+"=".repeat((4-e.length%4)%4)).replace(/\-/g,"+").replace(/_/g,"/"),n=atob(t),i=new Uint8Array(n.length);for(let a=0;a<n.length;++a)i[a]=n.charCodeAt(a);return i}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */!function(e){e[e.DATA_MESSAGE=1]="DATA_MESSAGE",e[e.DISPLAY_NOTIFICATION=3]="DISPLAY_NOTIFICATION"}(ue||(ue={})),function(e){e.PUSH_RECEIVED="push-received",e.NOTIFICATION_CLICKED="notification-clicked",e.FID_REGISTERED="fid-registered"}(de||(de={}));const pe="fcm_token_details_db",ge=5,we="fcm_token_object_Store",he=new o("messaging","Messaging",{"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"only-available-in-window":"This method is available in a Window context.","only-available-in-sw":"This method is available in a service worker context.","permission-default":"The notification permission was not granted and dismissed instead.","permission-blocked":"The notification permission was not granted and blocked instead.","unsupported-browser":"This browser doesn't support the API's required to use the Firebase SDK.","indexed-db-unsupported":"This browser doesn't support indexedDb.open() (ex. Safari iFrame, Firefox Private Browsing, etc)","failed-service-worker-registration":"We are unable to register the default service worker. {$browserErrorMessage}","token-subscribe-failed":"A problem occurred while subscribing the user to FCM: {$errorInfo}","token-subscribe-no-token":"FCM returned no token when subscribing the user to push.","fid-registration-failed":"A problem occurred while creating an FCM registration via FID: {$errorInfo}","fid-unregister-failed":"A problem occurred while unregistering the FCM registration via FID: {$errorInfo}","fid-registration-idb-schema-unavailable":"Unable to read or persist FID registration metadata because the messaging IndexedDB schema is unavailable (for example, the database could not be upgraded to the latest version).","token-unsubscribe-failed":"A problem occurred while unsubscribing the user from FCM: {$errorInfo}","token-update-failed":"A problem occurred while updating the user from FCM: {$errorInfo}","token-update-no-token":"FCM returned no token when updating the user to push.","use-sw-after-get-token":"The useServiceWorker() method may only be called once and must be called before calling getToken() to ensure your service worker is used.","invalid-sw-registration":"The input to useServiceWorker() must be a ServiceWorkerRegistration.","invalid-bg-handler":"The input to setBackgroundMessageHandler() must be a function.","invalid-vapid-key":"The public VAPID key must be a string.","use-vapid-key-after-get-token":"The usePublicVapidKey() method may only be called once and must be called before calling getToken() to ensure your VAPID key is used.","invalid-on-registered-handler":"No onRegistered callback handler was provided or registered. Implement onRegistered() before register()."}),ye="firebase-messaging-database",me=2,be="firebase-messaging-store",ve="firebase-messaging-fid-registration-store";let ke={openDB:s,deleteDB:g},Ie=null;function Se(e){return{upgrade:(t,n)=>{!function(e,t,n){switch(t){case 0:if(e.createObjectStore(be),1===n)break;case 1:2===n&&e.createObjectStore(ve)}}(t,n,e)},blocked:()=>{},blocking:(e,t,n)=>{var i;Ie=null,null===(i=n.target)||void 0===i||i.close()},terminated:()=>{Ie=null}}}function Te(){if(!Ie){const e=ke.openDB(ye,me,Se(2));Ie=e.catch(()=>ke.openDB(ye,me-1,Se(1)))}return Ie}function Ce(e,t){return e.objectStoreNames.contains(t)}function De(e){if(!Ce(e,ve))throw he.create("fid-registration-idb-schema-unavailable")}async function Pe(e){const t=Ne(e),n=await Te(),i=await n.transaction(be).objectStore(be).get(t);if(i)return i;{const t=await async function(e){if("databases"in indexedDB){const e=(await indexedDB.databases()).map(e=>e.name);if(!e.includes(pe))return null}let t=null;return(await s(pe,ge,{upgrade:async(n,i,a,r)=>{if(i<2)return;if(!n.objectStoreNames.contains(we))return;const o=r.objectStore(we),s=await o.index("fcmSenderId").get(e);if(await o.clear(),s)if(2===i){var c;const e=s;if(!e.auth||!e.p256dh||!e.endpoint)return;t={token:e.fcmToken,createTime:null!==(c=e.createTime)&&void 0!==c?c:Date.now(),subscriptionOptions:{auth:e.auth,p256dh:e.p256dh,endpoint:e.endpoint,swScope:e.swScope,vapidKey:"string"==typeof e.vapidKey?e.vapidKey:fe(e.vapidKey)}}}else if(3===i){const e=s;t={token:e.fcmToken,createTime:e.createTime,subscriptionOptions:{auth:fe(e.auth),p256dh:fe(e.p256dh),endpoint:e.endpoint,swScope:e.swScope,vapidKey:fe(e.vapidKey)}}}else if(4===i){const e=s;t={token:e.fcmToken,createTime:e.createTime,subscriptionOptions:{auth:fe(e.auth),p256dh:fe(e.p256dh),endpoint:e.endpoint,swScope:e.swScope,vapidKey:fe(e.vapidKey)}}}}})).close(),await g(pe),await g("fcm_vapid_details_db"),await g("undefined"),function(e){if(!e||!e.subscriptionOptions)return!1;const{subscriptionOptions:t}=e;return"number"==typeof e.createTime&&e.createTime>0&&"string"==typeof e.token&&e.token.length>0&&"string"==typeof t.auth&&t.auth.length>0&&"string"==typeof t.p256dh&&t.p256dh.length>0&&"string"==typeof t.endpoint&&t.endpoint.length>0&&"string"==typeof t.swScope&&t.swScope.length>0&&"string"==typeof t.vapidKey&&t.vapidKey.length>0}
/**
             * @license
             * Copyright 2017 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(t)?t:null}(e.appConfig.senderId);if(t)return await Re(e,t),t}}async function Re(e,t){const n=Ne(e),i=await Te(),a=[be],r=Ce(i,ve);r&&a.push(ve);const o=i.transaction(a,"readwrite");return await o.objectStore(be).put(t,n),r&&await o.objectStore(ve).delete(n),await o.done,t}async function _e(e){const t=Ne(e),n=(await Te()).transaction(be,"readwrite");await n.objectStore(be).delete(t),await n.done}async function je(e){const t=Ne(e),n=await Te();return De(n),await n.transaction(ve).objectStore(ve).get(t)}async function Ee(e){const t=Ne(e),n=await Te();De(n);const i=n.transaction(ve,"readwrite");await i.objectStore(ve).delete(t),await i.done}function Ne({appConfig:e}){return e.appId}const Ke="@firebase/messaging",Me="0.13.0",Oe=3,Ae=1e3;async function He(e,t){var n,i;const a=await Ue(e),r=Le(t,e.appConfig.appName,!0),o={method:"POST",headers:a,body:JSON.stringify(r)};let s,c;try{s=await async function(e,t,n){let i;for(let r=0;r<t;r++)try{return await e()}catch(a){if(i=a,r<t-1){const e=n*Math.pow(2,r);await new Promise(t=>setTimeout(t,e))}}throw i}(()=>fetch(qe(e.appConfig),o),Oe,Ae)}catch(d){throw he.create("fid-registration-failed",{errorInfo:null==d?void 0:d.toString()})}if(s.ok){const e=await async function(e){const t=await e.text();if(!t.trim())throw he.create("fid-registration-failed",{errorInfo:"CreateRegistration succeeded but response body is empty"});let n;try{n=JSON.parse(t)}catch{throw he.create("fid-registration-failed",{errorInfo:"CreateRegistration succeeded but response body is not valid JSON"})}const i=n.name;if("string"!=typeof i||0===i.length)throw he.create("fid-registration-failed",{errorInfo:"CreateRegistration succeeded but response did not include a non-empty name"});return function(e){const t=e.indexOf(Fe);if(-1!==t){const n=e.slice(t+Fe.length);if(n.length>0)return n}throw he.create("fid-registration-failed",{errorInfo:"CreateRegistration succeeded but response name is not a valid registration resource name"})}(i)}(s);return{responseFid:e}}try{c=await s.json()}catch(d){throw he.create("fid-registration-failed",{errorInfo:s.statusText})}const u=null!==(n=null===(i=c.error)||void 0===i?void 0:i.message)&&void 0!==n?n:s.statusText;throw he.create("fid-registration-failed",{errorInfo:u})}async function xe(e,t){const n={method:"DELETE",headers:await Ue(e)};let i;try{i=await fetch(`${qe(e.appConfig)}/${t}`,n)}catch(o){throw he.create("fid-unregister-failed",{errorInfo:null==o?void 0:o.toString()})}if(!i.ok)try{var a,r;const e=await i.json();throw null!==(a=null===(r=e.error)||void 0===r?void 0:r.message)&&void 0!==a?a:i.statusText}catch(o){throw he.create("fid-unregister-failed",{errorInfo:"string"==typeof o&&o||i.statusText||(null==o?void 0:o.toString())})}}const Fe="/registrations/";async function $e(e,t){const n={method:"DELETE",headers:await Ue(e)};try{const i=await fetch(`${qe(e.appConfig)}/${t}`,n),a=await i.json();if(a.error){const e=a.error.message;throw he.create("token-unsubscribe-failed",{errorInfo:e})}}catch(i){throw he.create("token-unsubscribe-failed",{errorInfo:null==i?void 0:i.toString()})}}function qe({projectId:e}){return`${oe}/projects/${e}/registrations`}async function Ue({appConfig:e,installations:t}){const n=await t.getToken();return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e.apiKey,"x-goog-firebase-installations-auth":`FIS ${n}`})}function Be(e,t){var n;try{if(/^[a-zA-Z][a-zA-Z\d+\-.]*:/.test(e))return new URL(e).host}catch{}try{var i;if("undefined"!=typeof self&&null!==(i=self.location)&&void 0!==i&&i.href)return new URL(e,self.location.origin).host}catch{}return"undefined"!=typeof self&&null!==(n=self.location)&&void 0!==n&&n.host?self.location.host:t}function Le({p256dh:e,auth:t,endpoint:n,vapidKey:i,swScope:a},r,o){const s={web:{origin:Be(a,r),endpoint:n,auth:t,p256dh:e}};return o&&(s.fcm_sdk_version=Me),i!==re&&(s.web.applicationPubKey=i),s}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */const Ve=6048e5;async function We(e){const t=await async function(e,t){const n=await e.pushManager.getSubscription();return n||e.pushManager.subscribe({userVisibleOnly:!0,applicationServerKey:le(t)})}(e.swRegistration,e.vapidKey),n={vapidKey:e.vapidKey,swScope:e.swRegistration.scope,endpoint:t.endpoint,auth:fe(t.getKey("auth")),p256dh:fe(t.getKey("p256dh"))},i=await Pe(e.firebaseDependencies);if(i){if(function(e,t){const n=t.vapidKey===e.vapidKey,i=t.endpoint===e.endpoint,a=t.auth===e.auth,r=t.p256dh===e.p256dh;return n&&i&&a&&r}(i.subscriptionOptions,n))return Date.now()>=i.createTime+Ve?async function(e,t){try{const n=await async function(e,t){const n=await Ue(e),i=Le(t.subscriptionOptions,e.appConfig.appName,!1),a={method:"PATCH",headers:n,body:JSON.stringify(i)};let r;try{const n=await fetch(`${qe(e.appConfig)}/${t.token}`,a);r=await n.json()}catch(o){throw he.create("token-update-failed",{errorInfo:null==o?void 0:o.toString()})}if(r.error){const e=r.error.message;throw he.create("token-update-failed",{errorInfo:e})}if(!r.token)throw he.create("token-update-no-token");return r.token}(e.firebaseDependencies,t),i={...t,token:n,createTime:Date.now()};return await Re(e.firebaseDependencies,i),n}catch(n){throw n}}(e,{token:i.token,createTime:Date.now(),subscriptionOptions:n}):i.token;try{await $e(e.firebaseDependencies,i.token)}catch(a){console.warn(a)}return ze(e.firebaseDependencies,n)}return ze(e.firebaseDependencies,n)}async function Je(e){const t=await Pe(e.firebaseDependencies);t?await async function(e,t){await $e(e.firebaseDependencies,t.token),await _e(e.firebaseDependencies),await Ge(e.firebaseDependencies)}(e,t):await async function(e){const t=await je(e.firebaseDependencies).catch(()=>{}),n=null==t?void 0:t.fid;n&&await xe(e.firebaseDependencies,n),await Ge(e.firebaseDependencies),n&&function(e,t){const n=e.onUnregisteredHandler;n&&("function"==typeof n?n(t):n.next(t))}
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(e,n)}(e);const n=await e.swRegistration.pushManager.getSubscription();return!n||n.unsubscribe()}async function ze(e,t){const n=await async function(e,t){const n=await Ue(e),i=Le(t,e.appConfig.appName,!1),a={method:"POST",headers:n,body:JSON.stringify(i)};let r;try{const t=await fetch(qe(e.appConfig),a);r=await t.json()}catch(o){throw he.create("token-subscribe-failed",{errorInfo:null==o?void 0:o.toString()})}if(r.error){const e=r.error.message;throw he.create("token-subscribe-failed",{errorInfo:e})}if(!r.token)throw he.create("token-subscribe-no-token");return r.token}(e,t),i={token:n,createTime:Date.now(),subscriptionOptions:t};return await Re(e,i),i.token}async function Ge(e){try{await Ee(e)}catch{}}async function Qe(e){try{e.swRegistration=await navigator.serviceWorker.register(ie,{scope:ae}),e.swRegistration.update().catch(()=>{}),await async function(e){return new Promise((t,n)=>{const i=setTimeout(()=>n(new Error(`Service worker not registered after ${ce} ms`)),ce),a=e.installing||e.waiting;e.active?(clearTimeout(i),t()):a?a.onstatechange=e=>{var n;"activated"===(null===(n=e.target)||void 0===n?void 0:n.state)&&(a.onstatechange=null,clearTimeout(i),t())}:(clearTimeout(i),n(new Error("No incoming service worker found.")))})}
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(e.swRegistration)}catch(t){throw he.create("failed-service-worker-registration",{browserErrorMessage:null==t?void 0:t.message})}}async function Ye(e,t){if(t||e.swRegistration||await Qe(e),t||!e.swRegistration){if(!(t instanceof ServiceWorkerRegistration))throw he.create("invalid-sw-registration");e.swRegistration=t}}
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */async function Ze(e,t){t?e.vapidKey=t:e.vapidKey||(e.vapidKey=re)}
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */const Xe=3;async function et(e,t){const n=await async function(e,t){const n=await e.pushManager.getSubscription();return n||e.pushManager.subscribe({userVisibleOnly:!0,applicationServerKey:le(t)})}
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(e.swRegistration,e.vapidKey),i={vapidKey:e.vapidKey,swScope:e.swRegistration.scope,endpoint:n.endpoint,auth:fe(n.getKey("auth")),p256dh:fe(n.getKey("p256dh"))},a=e.firebaseDependencies.installations;for(let r=0;r<Xe;r++){const{responseFid:n}=await He(e.firebaseDependencies,i);if(n===t)return;r<Xe-1&&await a.getToken(!0)}throw he.create("fid-registration-failed",{errorInfo:"CreateRegistration response FID does not match Firebase Installation ID"})}const tt=6048e5;async function nt(e,t){if(!navigator)throw he.create("only-available-in-window");if("default"===Notification.permission&&await Notification.requestPermission(),"granted"!==Notification.permission)throw he.create("permission-blocked");if(!e.onRegisteredHandler)throw he.create("invalid-on-registered-handler");await Ze(e,null==t?void 0:t.vapidKey),await Ye(e,null==t?void 0:t.serviceWorkerRegistration);const n=e._registerNotifyChain.catch(()=>{});return e._registerNotifyChain=n.then(async()=>{const t=await e.firebaseDependencies.installations.getId(),n=await je(e.firebaseDependencies),i=Date.now();if((!n||n.fid!==t||i>=n.lastRegisterTime+tt)&&(await et(e,t),await async function(e,t){const n=Ne(e),i=await Te();De(i);const a=i.transaction([be,ve],"readwrite");return await a.objectStore(ve).put(t,n),await a.objectStore(be).delete(n),await a.done,t}(e.firebaseDependencies,{fid:t,lastRegisterTime:i,vapidKey:e.vapidKey})),!e.onRegisteredHandler)throw he.create("invalid-on-registered-handler");!function(e,t){const n=e.onRegisteredHandler;n&&("function"==typeof n?n(t):n.next(t))}(e,t)}),e._registerNotifyChain}
/**
             * @license
             * Copyright 2026 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
function it(e){const t={from:e.from,collapseKey:e.collapse_key,messageId:e.fcmMessageId};return function(e,t){if(!t.notification)return;e.notification={};const n=t.notification.title;n&&(e.notification.title=n);const i=t.notification.body;i&&(e.notification.body=i);const a=t.notification.image;a&&(e.notification.image=a);const r=t.notification.icon;r&&(e.notification.icon=r)}(t,e),function(e,t){t.data&&(e.data=t.data)}(t,e),function(e,t){var n,i,a,r,o;if(!(t.fcmOptions||null!==(n=t.notification)&&void 0!==n&&n.click_action))return;e.fcmOptions={};const s=null!==(i=null===(a=t.fcmOptions)||void 0===a?void 0:a.link)&&void 0!==i?i:null===(r=t.notification)||void 0===r?void 0:r.click_action;s&&(e.fcmOptions.link=s);const c=null===(o=t.fcmOptions)||void 0===o?void 0:o.analytics_label;c&&(e.fcmOptions.analyticsLabel=c)}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(t,e),t}function at(e){return he.create("missing-app-config-values",{valueName:e})}
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */class rt{constructor(e,t,n){this.deliveryMetricsExportedToBigQueryEnabled=!1,this.onBackgroundMessageHandler=null,this.onMessageHandler=null,this.onRegisteredHandler=null,this.onUnregisteredHandler=null,this._registerNotifyChain=Promise.resolve(),this._fidChangeUnsubscribe=null,this.logEvents=[],this.logQueue={state:"stopped"};const i=
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
function(e){if(!e||!e.options)throw at("App Configuration Object");if(!e.name)throw at("App Name");const t=["projectId","apiKey","appId","messagingSenderId"],{options:n}=e;for(const i of t)if(!n[i])throw at(i);return{appName:e.name,projectId:n.projectId,apiKey:n.apiKey,appId:n.appId,senderId:n.messagingSenderId}}(e);this.firebaseDependencies={app:e,appConfig:i,installations:t,analyticsProvider:n}}_delete(){return this._fidChangeUnsubscribe&&(this._fidChangeUnsubscribe(),this._fidChangeUnsubscribe=null),"scheduled"===this.logQueue.state&&clearTimeout(this.logQueue.timerId),this.logQueue={state:"stopped"},Promise.resolve()}}
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */async function ot(e,t){if(!navigator)throw he.create("only-available-in-window");if("default"===Notification.permission&&await Notification.requestPermission(),"granted"!==Notification.permission)throw he.create("permission-blocked");return await Ze(e,null==t?void 0:t.vapidKey),await Ye(e,null==t?void 0:t.serviceWorkerRegistration),We(e)}
/**
             * @license
             * Copyright 2019 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */async function st(e,t,n){const i=function(e){switch(e){case de.NOTIFICATION_CLICKED:return"notification_open";case de.PUSH_RECEIVED:return"notification_foreground";default:throw new Error}}
/**
             * @license
             * Copyright 2017 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */(t);(await e.firebaseDependencies.analyticsProvider.get()).logEvent(i,{message_id:n[se],message_name:n["google.c.a.c_l"],message_time:n["google.c.a.ts"],message_device_time:Math.floor(Date.now()/1e3)})}async function ct(e,t){const n=t.data;if(!n.isFirebaseMessaging)return;if(e.onMessageHandler&&n.messageType===de.PUSH_RECEIVED&&("function"==typeof e.onMessageHandler?e.onMessageHandler(it(n)):e.onMessageHandler.next(it(n))),e.onRegisteredHandler&&n.messageType===de.FID_REGISTERED){const t=n.fid;"function"==typeof e.onRegisteredHandler?e.onRegisteredHandler(t):e.onRegisteredHandler.next(t)}const i=n.data;var a;"object"==typeof(a=i)&&a&&se in a&&"1"===i["google.c.a.e"]&&await st(e,n.messageType,i)}
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */const ut=e=>{const t=e.getProvider("messaging").getImmediate();return{getToken:e=>ot(t,e),register:e=>nt(t,e)}};
/**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
async function dt(){try{await f()}catch(e){return!1}return"undefined"!=typeof window&&l()&&p()&&"serviceWorker"in navigator&&"PushManager"in window&&"Notification"in window&&"fetch"in window&&ServiceWorkerRegistration.prototype.hasOwnProperty("showNotification")&&PushSubscription.prototype.hasOwnProperty("getKey")}i(new a("messaging",e=>{const t=new rt(e.getProvider("app").getImmediate(),e.getProvider("installations-internal").getImmediate(),e.getProvider("analytics-internal"));return navigator.serviceWorker.addEventListener("message",e=>ct(t,e)),t._fidChangeUnsubscribe=function(e,t){return X(t,()=>{(async()=>{e.onRegisteredHandler&&await je(e.firebaseDependencies)&&await nt(e).catch(()=>{})})()})}(t,e.getProvider("installations").getImmediate()),t},"PUBLIC")),i(new a("messaging-internal",ut,"PRIVATE")),n(Ke,Me),n(Ke,Me,"esm2020")}}});
