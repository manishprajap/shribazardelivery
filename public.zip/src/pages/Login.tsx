import React, { useState } from 'react';
import './Login.css';
import { apiPost } from '../api';
import OtpVerify from './OtpVerify';

interface LoginProps {
  onLogin: () => void;
  onRegisterClick: () => void;
  onTermsClick: () => void;
  onPrivacyClick: () => void;
}

const linkStyle: React.CSSProperties = {
  background: 'none',
  border: 'none',
  padding: 0,
  color: '#f97316',
  fontSize: 12,
  fontWeight: 600,
  textDecoration: 'underline',
  cursor: 'pointer',
  fontFamily: 'inherit',
};

const Login: React.FC<LoginProps> = ({
  onLogin,
  onTermsClick,
  onPrivacyClick,
}) => {
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

   // OTP step state
  const [otpStep, setOtpStep] = useState(false);
  const [otpPhone, setOtpPhone] = useState('');

  const getDeviceId = () => {
    let deviceId = localStorage.getItem('device_id');

    if (!deviceId) {
      deviceId = 'dev-' + Math.random().toString(36).substring(2, 10);
      localStorage.setItem('device_id', deviceId);
    }

    return deviceId;
  };

const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!login || !password) {
      setError('Please fill in all fields.');
      return;
    }

    setLoading(true);

    try {
      // Step 1: Validate credentials and trigger OTP
      const data = await apiPost('delivery/login', {
        login: login,
        password: password,
        device_id: getDeviceId(),
      });

      // Backend sends OTP and returns the phone number to show on OTP screen
      setOtpPhone(data.phone || login);
      setOtpStep(true);

    } catch (err: any) {
      setError(err.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  

  // Show OTP screen after successful credential check
 if (otpStep) {
  return (
    <OtpVerify
      phone={otpPhone}
      roleId={4}
      onBack={() => {
        setOtpStep(false);
        setError('');
      }}
      onLoginSuccess={onLogin}
    />
  );
}


  
  return (
    <div className="login-root">
      <div className="login-brand">
        <div className="login-logo">
          <img src="/shrilogo.jpeg" alt="Shree logo" />
        </div>

        <p className="login-title">Shri Bazar</p>
        <p className="login-subtitle">Sign in to your account</p>
      </div>

      <div className="login-card">
        <form className="login-form" onSubmit={handleSubmit} noValidate>
          {/* Login */}
          <div className="form-group">
            <label htmlFor="login" className="form-label">
              Email Or Phone
            </label>

            <div className="input-wrapper">
              <input
                id="login"
                type="text"
                className="form-input"
                placeholder="Enter email or phone"
                value={login}
                onChange={(e) => setLogin(e.target.value)}
              />
            </div>
          </div>

          {/* Password */}
          <div className="form-group">
            <label htmlFor="password" className="form-label">
              Password
            </label>

            <div className="input-wrapper">
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                className="form-input"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />

              <button
                type="button"
                className="toggle-password"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>

            <div className="field-footer">
              <button type="button" className="forgot-link">
                Forgot password?
              </button>
            </div>
          </div>

          {/* Error */}
          {error && <div className="error-banner">{error}</div>}

          {/* Submit */}
          <button
            type="submit"
            className="submit-btn"
            disabled={loading}
          >
            {loading && <span className="btn-spinner" />}
            {loading ? 'Signing in…' : 'Sign in'}
          </button>

          {/* Terms & Privacy */}
          <p
            style={{
              textAlign: 'center',
              fontSize: 12,
              color: '#888',
              marginTop: 16,
              lineHeight: 1.6,
            }}
          >
            By signing in, you agree to our{' '}
            <button
              type="button"
              onClick={onTermsClick}
              style={linkStyle}
            >
              Terms & Conditions
            </button>
            {' '}and{' '}
            <button
              type="button"
              onClick={onPrivacyClick}
              style={linkStyle}
            >
              Privacy Policy
            </button>
          </p>
        </form>
      </div>

    </div>
  );
};

export default Login;