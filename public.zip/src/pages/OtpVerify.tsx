import React, { useState, useRef, useEffect } from 'react';
import { apiPost } from '../api';
import './OtpVerify.css';

interface OtpVerifyProps {
  phone: string;
  roleId: number; // 2=customer, 3=vendor, 4=delivery
  onBack: () => void;
  onLoginSuccess: () => void;
}

const OTP_LENGTH = 6;

const OtpVerify: React.FC<OtpVerifyProps> = ({
  phone,
  roleId,
  onBack,
  onLoginSuccess,
}) => {
  const [otp, setOtp] = useState<string[]>(Array(OTP_LENGTH).fill(''));
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(30);
  const [resendLoading, setResendLoading] = useState(false);

  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (resendTimer <= 0) return;

    const t = setTimeout(() => {
      setResendTimer((s) => s - 1);
    }, 1000);

    return () => clearTimeout(t);
  }, [resendTimer]);

  const handleChange = (index: number, value: string) => {
    if (!/^\d?$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    setError('');

    if (value && index < OTP_LENGTH - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (
    index: number,
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    const paste = e.clipboardData
      .getData('text')
      .replace(/\D/g, '')
      .slice(0, OTP_LENGTH);

    if (!paste) return;

    const newOtp = Array(OTP_LENGTH).fill('');

    paste.split('').forEach((digit, i) => {
      newOtp[i] = digit;
    });

    setOtp(newOtp);
  };

  const handleVerify = async () => {
  const code = otp.join('');

  if (code.length !== OTP_LENGTH) {
    setError('Please enter the complete 6-digit OTP.');
    return;
  }

  setLoading(true);
  setError('');

  try {
    const data = await apiPost('verify-otp', {
      phone,
      otp: code,
      role_id: roleId,
    });

    console.log('VERIFY RESPONSE:', data);

    // save token
    if (data.token) {
      localStorage.setItem('auth_token', data.token);
    }

    // save user
    if (data.user) {
      localStorage.setItem('auth_user', JSON.stringify(data.user));
    }

    // redirect to dashboard
    onLoginSuccess();

  } catch (err: any) {
    setError(err.message || 'Invalid OTP. Please try again.');
    setOtp(Array(OTP_LENGTH).fill(''));
    inputRefs.current[0]?.focus();
  } finally {
    setLoading(false);
  }
};

  const handleResend = async () => {
    setResendLoading(true);
    setError('');

    try {
      await apiPost('resend-otp', {
        phone,
        role_id: roleId,
      });

      setResendTimer(30);
      setOtp(Array(OTP_LENGTH).fill(''));
      inputRefs.current[0]?.focus();
    } catch (err: any) {
      setError(err.message || 'Failed to resend OTP.');
    } finally {
      setResendLoading(false);
    }
  };

  const maskedPhone = phone.replace(
    /(\d{2})\d{6}(\d{2})/,
    '$1xxxxxx$2'
  );

  return (
    <div className="otp-root">
      <button className="otp-back-btn" onClick={onBack}>
        ← Back
      </button>

      <div className="otp-icon">📱</div>

      <h2 className="otp-heading">Verify OTP</h2>

      <p className="otp-subtext">
        OTP sent to <strong>+91 {maskedPhone}</strong>
      </p>

      <div className="otp-boxes" onPaste={handlePaste}>
        {otp.map((digit, i) => (
          <input
            key={i}
            ref={(el) => {
              inputRefs.current[i] = el;
            }}
            type="tel"
            inputMode="numeric"
            maxLength={1}
            value={digit}
            onChange={(e) => handleChange(i, e.target.value)}
            onKeyDown={(e) => handleKeyDown(i, e)}
            className={`otp-input ${
              digit ? 'otp-input--filled' : ''
            } ${error ? 'otp-input--error' : ''}`}
          />
        ))}
      </div>

      {error && <p className="otp-error">{error}</p>}

      <button
        className="otp-verify-btn"
        onClick={handleVerify}
        disabled={loading}
      >
        {loading ? 'Verifying...' : 'Verify & Login'}
      </button>

      <div className="otp-resend">
        {resendTimer > 0 ? (
          <p>
            Resend OTP in <span className="otp-timer">{resendTimer}s</span>
          </p>
        ) : (
          <button
            className="otp-resend-btn"
            onClick={handleResend}
            disabled={resendLoading}
          >
            {resendLoading ? 'Sending...' : 'Resend OTP'}
          </button>
        )}
      </div>
    </div>
  );
};

export default OtpVerify;